// Use the Fetch API to make a GET request to the Random User API
fetch('https://randomuser.me/api/?results=22')
.then((response) => {
    // Convert the response data to JSON
    return response.json();
  })
  .then((data) => {
    // Log the data to the console
    console.log(data);
    // Store the results in a variable
    const users = data.results;
    // Loop through the results and log each user
    users.forEach((user) => {
      // Log the name, email and image source of each user
      console.log(`name: ${user.name.first} ${user.name.last} 
      email: ${user.email}
      registered: ${user.registered.date}
      image: ${user.picture.large}`);
    });
  })
  .catch((error) => {
    // Log the error if there is one
    console.log(error);
  });